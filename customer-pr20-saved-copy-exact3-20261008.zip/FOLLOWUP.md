# 저장 견적 현재 기준 안내 · exact3 후속

2026-10-08. 개발PM이 읽은 CONTRACT-REVIEW.md SHA256 `b9011105a14a3e7ac8f808759806bfab80c0da69af5f9327da58b770afa12be8`의 누락 한 줄에 한정한 **작성자 CODE/MOCK** 수정이다. 독립 QA·현재 main 반영·배포 결과가 아니다.

## 변경

기존 소유 격리 후보 `D:/WORK/PopcornAI/worktrees/customer-approved-ui-integration-20261008`, branch `codex/customer-approved-ui-integration-20261008`, HEAD `41cf0751de2630a3abdacd62c77310b25cb334c3`에서 선행 기록의 9파일 hash와 비교하여 겹친 변경이 없음을 확인한 뒤 아래 세 행만 바꿨다.

- `mockups/mvp3/app.js:184`: savedQuote 안내를 “금액과 상품 기록은 보관 시점 기준입니다. 부품 구성과 사진은 조회 시점의 공개 상태를 따릅니다.”로 변경. 이 동일 표현은 결합 UI `0e3c665`에서는 177행에 있다.
- `mockups/mvp3/live-flow.js:160`: 불러오기 안내의 앞부분(브라우저 보관 상품명)을 유지하고 뒤에 동일 기준 문구를 적용.
- `mockups/mvp3/tests/product-images.test.cjs:74`: 기존 saved quote 테스트의 이전 안내 기대를 새 문구로 변경하고, 같은 검사에서 flow 불러오기 메시지도 정확히 같은 문구인지 기대하도록 보완. 기존 가격/사진/AI 고지/GET-only/보관 날짜 검증과 테스트명은 유지.

앱 동작·서버·모델·화면 구조·이미지 계약 변경 0. CSS/model/BOM test/index/API client/landing 6파일 hash 유지. 기존 후보의 staged5는 그대로이며 새 후속은 unstaged3: app/test는 MM, flow는 M. 이번 delta는 exact3이고 이전 후보 변경까지 포함한 HEAD 대비 파일 수는 6개다. commit/stage/push 없음.

## 정확한 패치와 hash

`saved-current-basis-exact3.patch`와 `.diff`는 같은 바이트, **3파일 각각 1행 교체(3 insertions/3 deletions)**. 기존 후보 B를 기준으로 한 delta이며, 기존 대형 후보 패치를 대체하지 않는다. 원본 B 및 결합 UI 0e3c665의 app/flow 복사본에서 patch check/apply 성공 후 기대 파일 바이트 전체가 일치함을 확인했다. 결합 UI 검증의 test 파일은 기존 B test를 사용한 복사본이다.

| 대상 | SHA256 |
|---|---|
| exact3 patch/diff (4936 bytes) | `7cf00cf6b43342c1ede13bc7b55f125032c02f338df0c480655d9d1a19b4a162` |
| 변경 후 app.js (42206 bytes) | `62b562fb99943a6613e8807e281d8e3978c9234ab473daec497ed5e6852250cf` |
| 변경 후 live-flow.js (12917 bytes) | `a2089ca29e1a1bfe007f84e854311d42da29b002d689cfd388e43a0e507f7eee` |
| 변경 후 product-images.test.cjs (20266 bytes) | `ee7971d9a018fbe72893500c1e68b05747571c5a4db61c0615b477679a62a3a4` |

`manifest.json`에 수정 전후 9파일 및 patch hash, 보호 파일 동일성, 두 기준 apply 결과를 남겼다. CRLF를 유지한 바이트 교체이고 `git -c core.autocrlf=false -c core.whitespace=cr-at-eol diff --check` exit0.

초기 artifact 검사에서 상위 `D:/WORK/PopcornAI` 저장소의 하위 디렉터리 prefix 때문에 `git apply`가 세 경로를 건너뛰고 exit0을 반환했다. 전체 바이트 대조가 미적용을 발견해 PASS로 처리하지 않았다. 임시 복사본에 독립 Git 경계를 만든 뒤 수정된 artifact harness에서 위 두 기준 적용·정확 바이트를 확인했다. 제품 수정은 반복하지 않았다.

## 최소 기존 검사 — 첫 실행 실패, 재실행 없음

전체 suite를 돌리지 않고 아래 기존 saved quote 검사 한 건만 정확 이름으로 선택하여 **1회 시도**했다.

```text
node --test --test-name-pattern=^generated-media: saved quote consumes only its own photo and retains saved price/date without original-photo wording$ mockups/mvp3/tests/product-images.test.cjs
```

실제 Node는 `C:/Users/leon2/AppData/Local/hermes/node/node.exe`. `Cannot find module 'jsdom'`로 파일 로드에서 exit1. **검사 본문 실행 전 실패이며 PASS 0, 문구 검증 미완료**다. 해당 실패에서 검증을 중단했고 자동 재실행 0회. `selected-saved-copy-run01.txt` 및 `test-run.json`에 원출력/명령/cwd/exit/hash 보존.

후속 참고만: runtime dependency 도구가 제공한 Node packages 경로는 `C:/Users/leon2/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules`이지만 해당 경로의 jsdom/package.json 확인 결과는 False였다. 도구의 패키지 경로 안내만으로 jsdom 가용성을 확정하지 않는다. 기존 검사에서 사용한 jsdom 실행 경로를 재확보해야 하며, 이번에는 환경 변경·설치·재실행하지 않았다.

실제 DB/API 쓰기, 브라우저, 서버 시작/재시작, 전체 suite, 배포 모두 0. 수정/패치 인계 완료와 최소 검사 미완료를 구분한다.
