# 조립 완성 예시 이미지 — 104개 구성

104/104개 구성의 PNG 원본과 웹용 WebP를 저장했습니다. 남은 구성은 0개입니다. 독립 이미지 96개를 제작했고, 동일한 시각 부품 조합 및 불투명 패널 예외에 따라 8개 구성에서 재사용했습니다.

모든 이미지는 **AI 생성 조립 완성 예시이며 실제 조립 사진이 아닙니다.** 케이스 원본 사진과 해당 구성의 공랭·수랭, 색상, LED 및 주요 팬 배치를 기준으로 제작했습니다. 메인보드 인쇄, 배선, 나사, GPU 장착 방향, 디지털 쿨러 수치는 단순화될 수 있습니다. LED 색은 참조 사진을 따른 예시이며 출고 고정 설정을 보장하지 않습니다. 실물 조립이나 물리 호환성 검증 자료로 사용하지 않습니다.

## 결과 보기

- 로컬 미리보기: http://127.0.0.1:8766/assembled-pc-images/
- 파일 미리보기: `index.html`
- 원본: `originals/{configuration_id}.png`
- 웹용: `web/{configuration_id}.webp` — 최대 1200×1200, WebP quality 90
- 전체 매핑·참조·쿨링·LED·검수 메모·해시: `manifest.json`
- 업로드 준비 목록: `upload-list.json`, `upload-list.csv` (publish=false)
- 재사용 목록: `reuse-list.json`
- 검증 결과: `verification.json`

## 근거와 재현 기록

2026-09-28 구성 카탈로그와 부품 데이터, 제품 원본 이미지 manifest, 읽기 전용 DB 스냅샷을 사용했습니다. DB의 104개 구성 부품 코드·슬롯·수량이 카탈로그와 일치합니다. `db-source-snapshot.json`에 당시 구성 revision과 부품 설명을 보존하고, 이미지 manifest에 제품 원본 경로·출처 URL과 DB image_asset 정보를 기록했습니다.

`generation-groups.json`은 케이스·쿨러·GPU·RAM 수량·메인보드가 같은 조합별 97개 그룹입니다. 불투명 N1 흰색 패널로 내부가 가려지는 G015는 G012의 닫힌 외관을 재사용했으며 예외를 기록했습니다.

`prompt-Gxxx.txt`와 `effective-jobs.json`에 기본 프롬프트·참조 파일이 있습니다. 검수된 생성본을 케이스 참조로 바꾸거나 보정한 호출은 `invocation-Gxxx*.json`을 함께 확인합니다. 초기 별도 프롬프트 및 수정 이력은 `prompt-N02.txt`, `edits-log.md`, manifest의 prompt_file에 남겼습니다. `generated-source-paths.json`은 세션에 남아 있던 생성 도구 원본 경로를 보조 기록한 파일입니다. 최종 전달 원본은 항상 manifest의 generated_original을 기준으로 합니다. 같은 프롬프트를 재실행해도 이미지가 완전히 같지는 않습니다.

모든 이미지 생성 및 시각 수정은 내장 image_gen 도구로 수행했습니다. Pillow는 PNG를 WebP로 변환하는 데 사용했습니다. `save_asset.py`는 저장과 갤러리를 갱신하고, `finalize.py`는 로컬 파일을 검사하여 메타데이터·전달 목록을 작성합니다. `prepare.py`와 `build_jobs.py`는 초기 준비 스크립트이므로 완료된 manifest를 유지하려면 다시 실행하지 마세요.

## 최종 검사

구성 ID 104개 일치, PNG 104개·WebP 104개 존재 및 디코딩, 정사각형 크기, WebP 해시 104개를 확인했습니다. 구성별 주요 외관은 생성 직후 시각 검토했습니다. 검증 오류는 0개입니다.

이 결과는 로컬 검토용입니다. DB 쓰기, 고객 공개 업로드, 저장소 코드·마이그레이션 수정, 커밋·푸시는 수행하지 않았습니다.
