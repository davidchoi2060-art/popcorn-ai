# 생성 대표 이미지 저장소·고객 연결 조사 정정 (2026-10-08)

## 정정
10/7 HANDOFF의 부품 원본 보관 조사만으로 대표 이미지 부재를 판단한 전제는 불충분했다. 생성 대표 이미지가 기존에 있으며 실제 사진을 새로 요구하거나 재생성할 사안으로 단정하지 않는다. 이전 기록: 기록/팝콘AI/결과/popcorn-two-office-image-audit-20261007.md.

## 직접 확인한 클라우드
2026-10-08 gcloud storage ls의 읽기 목록: 버킷 전체608객체, products/603 + pc-configurations/5. 대표 PNG3 및 영상2다. 프로젝트 project-045e861b-da1d-423a-b84의 buckets list에서는 이 버킷 하나가 조회됐다. 다른 프로젝트·계정의 자산 부재를 의미하지 않는다. 제품·DB·업로드·서비스·배포 변경과 이미지 생성은 모두 0.

저장소: https://console.cloud.google.com/storage/browser/popcorn-ai-product-media-045e861b?project=project-045e861b-da1d-423a-b84

N07 기존 선택 대표:
https://console.cloud.google.com/storage/browser/_details/popcorn-ai-product-media-045e861b/pc-configurations/4fd70b96-2e26-4621-8f6a-0ab6ad641c24/representative.png?project=project-045e861b-da1d-423a-b84
객체 생성 시각 2026-10-02 12:03:26.128 +09:00. 당시 중앙 결과와 decision-log는 ready/complete/selected=true 및 DB/다운로드 SHA256 30a10a64e3f0ac4e968c7bcab0acf4b10290959af14d6e8eebe846e5b40a318a 일치, 관리자 목록·상세 표시를 기록했다. 현재 객체 존재는 직접 확인했고 현재 DB 선택/visual_basis는 재조회하지 않았다. 고객 공개·추천 승인은 이 결과와 별개다.

다른 대표 객체:
- pc-configurations/08850be4-72eb-46da-a9bc-61c8ea6aa26d/representative.png — 생성2026-10-02 15:49:42.977 +09:00. 당시 admin-new-live-tasks.json에서는 AC11F5AEA43924DBA 구성의 image_url과 연결돼 있다.
- pc-configurations/9f879ccb-17f9-4988-9dab-51dac712419c/representative.png — 생성2026-10-02 18:30:01.163 +09:00. 구성/선택 연결은 이번 범위 미확인.
정확한 모든 객체별 안정적 콘솔 링크는 object-links.json에 저장했다. 비밀·서명 URL은 없다.

## 113835 / 113836 생성본과 연결
assembled-pc-images-20260929의 104/104 생성본 manifest에 P113835와 P113836이 있다. 각각 originals/P113835.png 및 originals/P113836.png, 웹본 web/P113835.webp 및 web/P113836.webp. P113836은 시각 부품 조합 예외에 따른 P113838 재사용이 manifest에 명시돼 있으며 임의 대체가 아니다.
원본 SHA: P113835=f3b7b3705e3c4e5fe3914ab5e9d8e6ca1dedf276822946a580fbc0eb78e1251b, P113836=dfc6a733f425dfec21e3ae50c078ce3b6653f862a8413eb57fe718070cb3c48b.
당시 verification은 public_upload_performed=false/database_write_performed=false이다. 이는 9/29 전달 당시의 경계다. 현재 확인한 클라우드 객체3개의 키는 job UUID라 두 구성과 같은 것으로 단정할 수 없다. 두 구성 생성본의 후속 다른 저장소 업로드 여부는 미확인이다.

최초 확보된 연결 누락 증거: read-only-snapshot.json captured_at=2026-10-01 07:54:35.998634 UTC(16:54:35.998634 KST)에서 P113835/P113836의 image_url은 각각 CASE부품129552/129551 경로다. 10/2 관리자 목록 snapshot에서도 동일 fallback이 보인다. 10/7 고객 추천 관측에서는 이미지 필드 없음 및 두 SKU product-images GET 8건404다. 이 시점들은 확인 증거이며 실제 누락 발생 시각이나 낭비 기간을 뜻하지 않는다. 정확한 생성 호출시각은 manifest에 없고 9/29 폴더/완료 산출물만으로 시각을 만들어 내지 않는다.

## 연결 계약과 후속 파일 범위
운영 확인 기준 커밋 1ecf4dfe31e670bed14c7ce218e88ab187ffc197:
- api/pc_media.py는 product_images.MEDIA_BUCKET을 공유한다. 따라서 알려진 버킷은 부품 원본뿐 아니라 생성 대표 이미지 저장소도 맞다. ready asset key는 pc-configurations/<job UUID>/representative.png. 선택은 구성ID+jobID 및 현재 visual_basis 일치를 확인하며 DB selected만 변경한다.
- api/pc_configuration_copy.py는 selected/ready/current visual_basis의 대표를 관리자 /api/admin/pc-media/<configuration>/images/<job>로 제공하고, 없으면 CASE 사진 fallback을 제공한다.
- api/grid_workstations.py::_item은 판매상품 code/name/price/spec/stock/mall_url만 반환하고 대표 이미지·구성 자산을 반환하지 않는다. 제품 원본 API는 product_explanations.image_asset 경로라 pc_media_jobs 자산을 직접 소비하지 않는다.
- 고객 UI가 이 관리자 URL을 그대로 사용하면 권한 경계를 넘는다. 고객 허용 조건을 갖춘 별도 공개 미디어 소비 계약과 선택/current 기준을 연결해야 한다.

최소 보완 후보 파일: api/grid_workstations.py(판매SKU↔구성 매핑 및 공개 이미지 응답), api/pc_media.py 또는 별도 공개 reader(선택/current 자산의 고객 허용 조건·읽기), 고객 UI 담당의 기존4파일 이미지 소비. product_images.py에 다른 namespace를 무조건 허용하거나 생성자산을 부품 image_asset으로 덮어쓰는 변경은 피한다. pc_configuration_copy.py는 기존 선택/current 기준의 재사용 근거이며 임의 상태 변경 대상이 아니다. 실제 SKU↔구성↔job 매핑/승인 근거를 읽고 범위를 확정해야 한다.

남은 읽기 확인: 현재 pc_media_jobs의 세 job 구성ID/selected/status/visual_basis/asset 및 P113835/P113836 전체 과거 job, 구성 현재 visual_basis, 고객 공개 허용 조건. 운영 DB 재조회는 이번 조사에서 수행하지 않았다. 확인된 기존 자산부터 연결하며 새 생성이나 업로드를 해결책으로 앞세우지 않는다.
