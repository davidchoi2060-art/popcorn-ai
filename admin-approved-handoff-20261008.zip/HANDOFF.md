# 관리자 이미지 목록 출처 표시 시안 — 2026-10-08

**시안 준비·자체 시각 검토 완료. 대표 시안 확인은 아직 미완료이며 제품 구현은 후속 단계다.** 기존 대표이미지를 다시 생성하지 않았다. 사용자 기존 원본 재사용·케이스 중심 맥락과 기존 관리자 배치를 유지하는 표시 제안이다. 제품코드 수정0.

## 바로 확인

- 전체 화면: [로컬 미리보기](http://127.0.0.1:50932/index.html)
- 목록 우선: [출처별 목록](http://127.0.0.1:50932/index.html#gallery)
- 원본/생성/미확인: `#existing-ready`, `#generated-ready`, `#unknown-ready`
- 진행/실패: `#existing-running`, `#existing-failed` (PC에서는 각 행의 세 출처를 나란히 확인)
- 원본 HTML: `index.html`, 추가 표시 CSS: `design.css`.
- 계약 제안과 현 코드 근거: `API-DISPLAY-CONTRACT.md`.

현재 로컬 preview는 Python 표준 정적 HTTP 서버가 127.0.0.1:50932에 바인딩돼 있다. 제품 앱이나8790을 시작·재시작한 것이 아니다. 정적 파일 GET만 브라우저로 확인했다. 서버 종료 뒤 재현은 PowerShell에서 아래 명령을 사용한다. workdir는 D:/WORK/PopcornAI다.

```powershell
& 'C:\Users\leon2\AppData\Local\Programs\Python\Python312\python.exe' -u -m http.server 50932 --bind 127.0.0.1 --directory 'D:\WORK\PopcornAI\outputs\existing-media-origin-display-design-20261008'
```

## 최소 변경안

1. 갤러리 제목 “생성 이미지” → “이미지 목록”. 기존 shell/준비 2열/갤러리 3열·모바일 1열 구조, 전체/현재 구성 필터 위치 유지.
2. 각 항목의 **출처 배지와 처리 상태 배지를 분리**. generated는 AI 생성, existing_import는 기존 원본 반입, 누락/불명은 출처 미확인. running/failed/ready도 출처에 맞는 문구로 표시한다. “모든 작업은 생성”이라는 통칭을 없앤다.
3. 반입 항목의 null 모델은 “해당 없음 · 생성 실행 없음”. 원본 생성 시각·생성자 기록 없음과 현재 요청 등록 시각·등록 주체를 다른 행으로 표시한다. 개별 모델에 상단 기본 생성 설정을 대신 넣지 않는다.
4. 원본 재사용 승인 근거, 대표 선택, 고객 공개를 별도 행으로 표시한다. 재사용 승인은 현재 등록 실행 권한을 대신하지 않으며 ready/selected는 고객 공개 근거가 아니다. 근거 미연결은 미확인으로 유지한다.
5. 원본 반입 실패를 생성 실패나 재생성 필요로 안내하지 않는다. generated 저장 재시도는 기존 조건을 유지하고 import에 일반 worker 재시도를 붙이지 않는다. 선택 가능 조건·권한·공개 정책·새 endpoint를 바꾸는 제안이 아니다.

화면의 구간 이동 링크는 **검토 편의용 mock 링크**로, 새 제품 출처 필터·메뉴 IA를 신설하는 제안이 아니다. 관리자 메뉴는 기존 영역의 문구 배치만 재현한 비동작 stub이다. 실제 공통 shell 교체를 제안하지 않는다. 세부 설명은 native details로 접고 펼 수 있고, 기능 버튼은 전부 disabled다. JS/script/form/API 호출은 없다.

## 현재 동작 / 제안 / 미확인

**현재 소스에서 확인:** 지정 jobs()는 origin_kind를 반환하지 않는다. 소비자는 갤러리·running·selected preview를 생성 이미지로 통칭한다. 기존 created_at는 현재 작업 행 시각이고 actor는 현재 등록 주체다. 0133과 importer 후보는 existing_import/model null/원본 생성 정보 null 및 running/import_storage → ready/complete 구조를 갖는다. 일반 worker와 retry-storage는 generated origin을 방어한다. 이 내용은 코드 읽기 근거다.

**제안:** jobs의 origin_kind 안전 투영이 첫 필수 최소 필드다. 기존 status/phase/model/selected/current/created_at를 유지한다. 현재 등록 주체의 안전 표시값·원본 생성 정보·재사용 승인·공개 상태는 검증된 원천이 있는 경우에만 좁은 projection으로 추가하며, 없으면 미확인/기록 없음으로 표시한다. raw import_provenance, objectkey/bucket, 서버·원본 경로, 세션/토큰/보안값은 UI DTO나 화면에 넣지 않는다. 전체 원문 오류를 표시하지 않고 안전한 단계별 문구를 제안했다.

**미확인:** 실제 migration0133 적용, 운영 DB행, 실제 세션·CASE 근거·등록 grant 연결, 실제 GCS 등록, 실제 이미지 선택/고객 공개, 운영 API/E2E·배포는 이번 확인 대상이 아니다. CODE/MOCK 수용을 이러한 완료로 확대하지 않는다. 시안 작성자의 검토는 대표의 시안 승인도 아니다.

## 원본 이미지 재사용

시안 사진은 `D:/WORK/PopcornAI/outputs/assembled-pc-images-20260929/originals/P113835.png`를 **바이트 그대로 복사**한 것이다. SHA256 `f3b7b3705e3c4e5fe3914ab5e9d8e6ca1dedf276822946a580fbc0eb78e1251b`는 source/destination 동일하다. 검정 DAVEN N1 MESH 닫힌 측판 외관 원본을 “보관 원본 미리보기” 및 “기존 원본 반입 표시예”에만 쓴다. 생성 출처 예시에 이 사진을 대입하지 않고 빈 결과 영역을 사용했다. 다른 CASE 대입·새 이미지 생성/편집/변환0. 실제 등록이나 공개용 이미지 반입 실행이 아니다.

기존 보관 QA와 케이스 중심 결정은 `outputs/existing-media-actual-wiring-package-20261008/HANDOFF.md` 및 중앙 기록에서 읽었다. 이 시안은 그 재사용 승인을 다시 요청하거나 새로운 생성 정책을 만드는 것이 아니다. 현재 표시 승인과 후속 구현 순서만 분리한다.

## 실제 시안 검토

PC1440×1024와 모바일 override390×844에서 native 브라우저로 열었다. 모바일 DOM client375/실제 JPEG375×812였으며 요청 치수와 실제 캡처를 구분했다. PC 원본 JPEG1440×1024다. fullPage를 쓰거나 이미지를 늘여 캡처를 꾸미지 않았다.

- PC에서 세 출처의 ready/running/failed 9개 항목을 모두 확인했다. 3열, 기존 palette/서체, 출처별 문구, 모델 null 표시, 생성·등록 정보 구분 및 선택·공개 구분을 확인했다.
- 모바일에서 1열, 원본 반입·AI 생성·출처 미확인 완료 예시, 원본 반입 진행·실패를 확인했다. 카드 내용이 가로로 잘리지 않으며 접힌 반입 완료 카드는 한 viewport에서 핵심 정보와 선택 버튼을 확인할 수 있다.
- 원본 재사용 details 펼침/접힘을 실제 확인했다. 상세정보 열림에도 가로 overflow가 없었다.
- PC document scrollWidth/clientWidth1440/1440, 모바일375/375. 이미지 missing0. 모든 button disabled, scripts0, forms0, 이동 링크는 동일 페이지 fragment만 사용한다. 관찰한 warning/error console은 빈 배열이다.
- 자체 검토에서 필수 수정이 남아 있지 않다. 실제 대표 확인 및 이후 실제 계약/API 연결 검증은 남아 있다. 기존 제품 검사나 worker/DB test를 반복하지 않았다.

증거는 `evidence/browser-observations.json`, `evidence/console.json`, `evidence/image-metadata.json`, PC5장/mobile6장 viewport 캡처에 보존했다. 마지막 메뉴 stub 정리 뒤 PC ready/gallery/top/진행/실패 캡처를 최종 HTML로 다시 남겼다. `source-pins-before.json`/`source-pins-after.json`의 읽은 제품7파일 해시 동일. 산출물 해시는 `file-hashes.json` 참조.

## 이전 원응답 및 후속

기존 디자인 chat `01a11017-de14-74e2-849e-8cc62622a370`의 실제 이전 원응답 turn `01a1153b-7b58-7a41-af71-c5cb06f8f08b`를 read_thread로 확인했다. 원문은 “PC 배치 2건이 해소돼 디자인 범위에서 수용 가능으로 판정하고 PM에 전달했습니다”이며 제품 수정 없이 native mock을 대조한 디자인 역할을 확인했다. 그 고객 게이트웨이 수용을 이번 관리자 시안 수용으로 옮기지 않았다.

다음 순서는 PM이 이 구체 시안을 대표에게 보여주고 확인한 뒤, 그 범위로 표시/API 투영 구현을 배분하는 것이다. 이후 검증과 서버 반영은 각각 실제 결과로 판단한다. 이번 작업은 신규 output 폴더 안의 HTML/CSS mock·복사 자산·읽기 분석·캡처·인계만이다. backend/제품source/DB/PG/GCS/등록/선택/공개/배포/8790재시작/OneDrive신규쓰기0.
