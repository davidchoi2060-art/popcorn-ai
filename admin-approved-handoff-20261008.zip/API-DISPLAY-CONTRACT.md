# 관리자 이미지 출처 표시 — 읽기 근거 및 최소 계약 제안

시안 제안이며 API/backend 구현이나 DB 변경이 아니다. 기준 checkout은 `D:/WORK/PopcornAI/worktrees/existing-media-worker-origin-guard-20261008`이다. 현재 jobs()와 소비자에서 직접 확인한 사실과 이후 구현 후보를 구분한다.

## 현재 코드에서 확인한 것

- `api/pc_media.py:105-106` jobs() SELECT는 job_id/status/phase/error/visual_basis/model/selected/created_at/updated_at/staged_available를 반환한다. origin_kind·actor·import_provenance는 반환하지 않는다.
- `api/pc_media.py:115-118`는 current(visual_basis 비교), image_url, interrupted를 더한다. ready는 대표 선택이나 고객 공개를 뜻하지 않는다.
- `mockups/shared/pc-media.js:9-12`는 갤러리를 “생성 이미지”로, 모든 running을 “생성·저장 중”으로 표현한다. selected 미리보기 alt/표시도 AI 조립 예시로 통칭한다. 날짜는 j.created_at을 라벨 없이 표시한다. 최상단 s.model은 현재 생성 설정이며 개별 반입 항목의 모델이 아니다.
- `templates/admin/pc_media.html.j2:4`는 기존 admin shell의 본문, `pc-assets.css` 및 `pc-media.js`를 사용한다. 시안은 이 shell/2열 준비영역/3열 갤러리/모바일 1열 구조와 팔레트를 복사해 유지했다. 시안의 이동 링크는 검토 구간 이동용이며 실제 제품 필터 신설안이 아니다.
- `db/migrations/versions/0133_pc_media_import_provenance.py` 후보는 origin_kind를 generated/existing_import로 구분한다. existing_import는 model=NULL이고 original의 generation_model/generation_actor/generation_time도 JSON null이다. 이는 후보 schema/CODE 근거이며 실제 migration 적용을 이번에 확인한 것은 아니다.
- `api/pc_existing_media_import.py:175-184,387-405`는 actor를 현재 서버 등록 주체로 사용한다. 예약은 running/import_storage/selected=false/model=None, 완료는 ready/complete다. 현재 actor는 원본 생성자가 아니다.
- `api/pc_media.py:204-210,229-237`의 일반 worker·저장 재시도는 generated만 대상으로 한다. UI가 import 실패를 일반 생성/저장 재시도라고 안내하면 이 경계와 충돌한다.

## 필수 최소 표시 계약

**jobs 응답에 origin_kind를 안전하게 투영하는 것**이 출처 오표시 방지에 필요한 첫 최소 추가다. nullable/알 수 없는 값은 UI에서 “출처 미확인”으로 처리한다. `unknown`을 DB의 새 출처 정책이나 저장 enum으로 추가하는 제안이 아니다. model null, 날짜, 이미지 유무, 기존행이라는 이유로 origin을 추정하지 않는다.

기존 status/phase/current/selected/created_at/updated_at/model/image_url/staged_available/interrupted는 그대로 사용한다. 선택 가능 조건·생성 정책·등록 승인 동작을 이 시안에서 새로 정의하지 않는다. 시안의 버튼은 전체 disabled이며 실제 제품에서 모든 버튼을 비활성화하자는 정책이 아니다.

| 필드/표시 | 현재 근거 | 제안 및 값이 없을 때 |
|---|---|---|
| origin_kind | DB 후보에는 있으나 jobs()에 누락 | generated → AI 생성, existing_import → 기존 원본 반입, 그 외/누락 → 출처 미확인. 반드시 명시값 기준 |
| 현재 등록 시각 | jobs.created_at | “현재 등록” + “요청이 기록된 시각”. 등록/저장 완료 시각 또는 원본 생성 시각으로 바꾸지 않음. updated_at도 원본 생성 시각으로 쓰지 않음 |
| 등록/요청 주체 | job.actor는 서버 현재 주체, jobs에는 누락 | 권한 범위 안에서 `registration_actor_label: string|null` 안전 표시값을 제공하는 좁은 후보. raw actor/session 값은 출력하지 않으며 연결 전에는 미확인 |
| 원본 생성 시각·생성자 | import_provenance.original.generation_time/generation_actor는 현재 후보에서 null | “시각·생성자 기록 없음”. 향후 검증된 값이 있으면 별도 safe projection `original_created_at` / `original_creator_label`, 없으면 null 유지. 현재 등록값으로 대체하지 않음. 원문 provenance 통째 반환 불필요 |
| 개별 모델 | jobs.model | existing_import+null → “이번 등록 모델: 해당 없음 · 기존 원본 반입”. generated+값 → 해당 작업의 실제 기록값. generated+null → “모델 기록 없음”(상단 기본모델로 대체하지 않음). origin 불명+null → “모델 기록 없음”, 생성으로 분류하지 않음 |
| 원본 재사용 승인 | jobs에는 없음. provenance 존재만으로 현재 허가를 증명하지 못함 | UI 기본 “미확인”. 검증된 서버 원천이 연결된 경우에만 `reuse_approval_status` 같은 safe projection을 제안할 수 있음. 원본 재사용 판단과 현재 실행 grant/등록 권한을 구분. 이번에는 새 승인 저장소/판정 로직을 만들지 않음 |
| 대표 선택 | jobs.selected | ready와 별개로 표시. 기존 제품 선택 계약 유지. 미선택/선택됨 자체가 고객 공개를 증명하지 않음 |
| 고객 공개 | 현재 jobs/state 응답에 없음 | 항상 “미확인”으로 시작. 이후 검증된 별도 공개 원천의 `publication_status`가 연결될 때만 그 값을 표시. selected/ready/이미지URL 존재로 공개 상태를 추정하지 않음. 새 공개 정책 제안 아님 |

즉 origin 추가만으로 출처·상태 문구의 최소 개선은 가능하다. 나머지 표시 메타는 **실제 검증된 서버 원천이 있는 항목만** 좁게 투영하고, 미연결 정보를 채워 넣거나 불필요한 새 DB 필드를 만들지 않는다. 시안에서 “승인 근거 있음·선택됨·시각·주체” 값은 모든 것이 명시된 MOCK 표시예이다.

## 상태 문구 매핑 후보

| 출처 | running | failed | ready |
|---|---|---|---|
| generated | generation → 이미지 생성 중 / storage → 생성 이미지 저장 중 / 미확인 단계 → 생성 처리 중·단계 확인 필요 | generation → 이미지 생성 실패 / storage → 생성 이미지 저장 실패 / 그 외 → 생성 처리 실패·단계 확인 필요 | 생성·저장 완료 |
| existing_import | import_storage → 원본 등록·저장 중 / 그 외 → 원본 등록 처리 중·단계 확인 필요 | import_failed → 원본 등록 실패 / 그 외 → 원본 등록 처리 실패·단계 확인 필요 | 등록 완료 |
| 누락·알 수 없음 | 처리 중 | 처리 실패 | 준비됨 |

값이 불명인 status는 “상태 확인 필요”. interrupted는 출처별 기본 상태에 “작업 중단 가능 · 상태 확인 필요”를 덧붙이며 자동 재호출·새 UUID를 제안하지 않는다. generated/storage 실패의 기존 저장만 재시도 조건은 보존하되, import/출처 불명 항목에 그 버튼이나 “별도 재생성 필요” 안내를 재사용하지 않는다. import 재개 UI의 새로운 endpoint나 권한 계약은 이번 시안에 포함하지 않는다.

“생성 준비”는 기존의 생성 전용 영역으로 유지 가능하다. 그 영역의 busy 문구가 목록의 전체 running을 요약할 때는 generated만 생성 문구를 사용한다. 반입 작업이면 “원본 등록·저장 진행 중”, 출처 불명/혼합이면 “이미지 작업 진행 중”처럼 중립적으로 표시하는 후보이며, 실행 가능 조건 자체는 변경하지 않는다.

갤러리 제목은 “이미지 목록”, 필터 aria-label/빈 목록은 “이미지 필터 / 등록된 이미지 없음”으로 중립화한다. 선택된 preview의 chip/alt도 해당 출처 또는 “현재 선택된 대표 이미지”를 사용하여 반입 원본·출처 불명을 무조건 AI 신규생성으로 부르지 않는다.

## 표시 정보 경계

object key·bucket·로컬/서버 파일 경로·original_ref·세션/토큰·권한 원문·서버 설정/보안값·raw actor를 UI 표시 DTO에 포함하지 않는다. 기존 인증된 image_url을 재사용하고 내부 저장 위치를 안내에 넣지 않는다. 실패 문구는 status/phase의 안전한 일반 문구를 사용하고 임의 exception/error 원문을 그대로 노출하지 않는다. 이 제안은 현재 GET 응답의 보안 결함을 확정했다는 뜻이 아니라, 추가 표시 DTO를 좁게 유지하는 범위다.

현재 승인된 원본 재사용·케이스 중심 맥락을 보존한다. 다른 CASE 이미지 대입, 내부 부품 완전 일치 주장, 새 생성 자동 실행, 자동 대표 선택, 자동 공개를 제안하지 않는다. 구현·검증·서버 반영은 시안 확인 후 별도 단계다.
