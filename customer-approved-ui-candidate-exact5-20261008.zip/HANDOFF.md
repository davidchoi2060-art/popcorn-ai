# 고객 승인 결과·상세 통합 후보 exact5

2026-10-08. 승인된 결과·상세 구조를 accepted final exact2/copy2/public BOM exact4(슬롯 상속 속성 보완 포함)/generated photo exact3에서 좁게 통합했다. CODE/MOCK 후보와 적용 가능한 패치 인계까지 완료했다. 운영 반영·판매 가능·실제 사진 연결 완료는 아니다.

## 후보와 소유 범위

독립 clone `D:/WORK/PopcornAI/worktrees/customer-approved-ui-integration-20261008`, branch `codex/customer-approved-ui-integration-20261008`, HEAD `41cf0751de2630a3abdacd62c77310b25cb334c3`. 변경 다섯 파일만 로컬 staged 상태이며 commit/push/main/PR 변경/배포는 수행하지 않았다.

- `mockups/mvp3/app.js`: 승인 카드·상세 요약, native public BOM 펼침, 사진 소비, 선택 그룹 게임 문구, 기존 최종 확인 연결.
- `mockups/mvp3/styles.css`: 기존 자산·토큰을 사용한 결과·상세와 모바일 배치.
- `mockups/mvp3/live-model.js`: public_configuration·group game_context 공개 필드 정규화.
- `mockups/mvp3/tests/product-images.test.cjs`: 기존 사진 검사 7개와 통합 검사 5개. 기존 landing CTA 검사는 보존.
- `mockups/mvp3/tests/mvp3-public-bom.test.cjs`: 기존 8개와 실제 app/model/flow 허용 슬롯 5개. 실제 상담 진입 경로로 fixture URL 수정.

`live-flow.js`, `api-client.js`, `index.html`, `mockups/mvp1/main-landing.html`은 HEAD와 바이트 동일하다. flow 확장은 필요하지 않았다. 게임 안내는 선택 항목의 전역 index와 product_code 둘 다 일치하는 그룹에서 읽고, 보관/복구 견적에 이전 게임 안내를 섞지 않는다. 기존 앱 함수 29개의 photo 후보 대비 동일성을 다시 확인했다. DEV 소스 3개, archived source 23개, frozen photo 후보 3개는 이전 고정 해시와 같다. `protected-preservation.json`, `integration-scope-proof.json` 참조.

## 패치 선택과 PR10 중복 이전

두 패치는 대안이다. 함께 적용하지 않는다. 둘 다 다섯 파일만 포함하며 독립 raw-base Git fixture에서 apply --check/apply exit 0, 최종 다섯 파일 바이트 동일을 확인했다. CRLF를 보존한 diff --check와 JS syntax가 통과했다.

| 용도 | 파일 | base | bytes | SHA256 |
|---|---|---|---:|---|
| 기존 UI3가 이미 들어간 기준점에 추가 | customer-approved-ui-delta-from41cf-exact5.patch | 41cf0751de2630a3abdacd62c77310b25cb334c3 | 77438 | 728794afefb957509c70e534a0586803169a858babdaf8c08b77fe423d964f97 |
| PR10에서 UI3를 제외한 후 Codex 소유로 원 UI3+이번 통합을 보존 | customer-approved-ui-consolidated-from1ecf-exact5.patch | 1ecf4dfe31e670bed14c7ce218e88ab187ffc197 | 75287 | d32233cc4c9d0f51cf5e7a67d1eec8a0f854083a70a80e7a3d4688df3c13f5cc |

PR10 head `356df8a0dc2894096330b3f4b1292c1fbd544920`의 UI3 원문은 base41cf raw Git blob과 동일하다. cherry-pick `e7c249e77decad6f28ceb7a31d3b8b212c29ece9`에는 `mockups/mvp1/main-landing.html`도 있으므로 전체 commit을 제거하거나 통째로 이전하면 안 된다. 이 인계는 MVP3 UI 세 파일의 보존·소유 이전 근거다. PR10 실제 제외는 PM/Claude 작업으로 남긴다. base1ecf→41cf 사이 MVP3 차이는 정확히 기존 app/styles/product-images 테스트 3개뿐이었다. 다른 현재 head에는 임의 적용을 권하지 않으며 현재 정본과 비교해야 한다. `pr10-ui-source-proof.json`, `candidate-pins-and-patches.json`이 전체 source/hash 근거다.

## 현재 PR15 계약과 서버 후속

읽은 head `415c1dd2348539f4c77812097c85262712ce1b92`, base `d10934eb21910beecf94eee38349fb502231587c`. doc2 raw source SHA는 `pr15-contract-pins.json`에 고정했다. 현재 items는 public_configuration/photo를 전달하지 않으며, group-level game_context는 null일 수 있다. sold-offer reader는 고객 라우트가 없고, 생성 완성 사진은 관리자 경로만 있으며 customer SKU 공개 매핑이 없다. seed211/92/119를 실제 DB 통계로 쓰지 않았다.

현재 서버 그대로라면 기존 완제품 사양 + ‘부품 구성 정보는 아직 연결되지 않았어요’ + ‘이미지 준비 중’이 표시된다. 승인 구조를 삭제하지 않는 것은 PM의 명시적 복원 지시를 적용한 것이다. PR15 말미의 ‘BOM/사진 영역을 그리지 않는다’는 표현과 이 지시의 차이를 구분한다.

Claude 서버 작업에서 필요한 추가 계약:

1. `items[].public_configuration`: 실제 public sold-offer reader와 현재 SKU/offer/revision/publication 경계를 연결하고, source_reader/description/parts의 공개 projection을 전달. 브라우저 검증이 현재 revision·공개 승인 증명을 대신하지 않는다.
2. `items[].photo`: available/unavailable/temporarily_unavailable, available은 ai_assembly_example·정본 NOTICE·정확한 해당 SKU 고객 URL. 고객 GET 라우트와 실제 selected/current→object→SKU mapping→공개 허용→bytes를 서버에서 연결해야 한다. GCS 자산 존재나 관리자 ready가 고객 공개 완료를 뜻하지 않는다.
3. quote의 optional BOM/photo는 보관 시점 구성·가격과 현재 등록 자산의 의미를 명시해야 한다. 현 계약에서 absent이면 정상 fallback이며 보관 견적에 현 추천 게임 context를 주입하지 않는다.
4. 부품 사진·가격 배분·질문·변경은 별도 확인된 계약이 필요하다. standalone 부품 판매가를 완제품 가격의 배분으로 쓰지 않는다. CASE 원본/variant/admin/GCS 주소를 임의 사진 대체로 사용하지 않는다.

새 고객 질문·변경/게임 FPS·운영체제/주변기기/보증 확정은 없다. 상세 ‘이 견적 저장하기’는 기존 final 확인 화면으로 이동하며 바로 POST하지 않는다. 저장·인증·취소·복구 로직은 기존 소스 그대로다.

## 검증 근거와 실패 기록

서로 다른 대상 테스트 29개를 확인했다. 한 번에 29개를 새로 실행해 통과했다고 보고하지 않는다.

| 범위 | 결과·파일 |
|---|---|
| public BOM 기본 8개 | 첫 정상 runner 실행에서 8개 통과 후 첫 허용 슬롯 실패로 즉시 중단 — bom13-run02.txt |
| URL 수정 후 실패 1개/나머지 4개 | bom-corrected-first-case.txt / bom-remaining-four.txt, 각 1/4 통과 |
| photo 7 + 통합 5 | photo7-integration5-run01.txt, 12 통과 |
| 기존 model 대상 4 | model4-run01.txt, 4 통과 |
| 카드 우선/전체 폭 레이아웃/실제 disabled 변경 후 영향 범위 | 각 5개 통합 검사 통과 — layout-correction-five.txt, fullwidth-five.txt, disabled-controls-five.txt |
| 전체 폭 renderer 보완 후 허용 슬롯 5개 | fullwidth-role-five.txt, 5 통과 |

첫 reporter 초기화는 Windows D: 경로가 ESM scheme으로 해석돼 exit7, 테스트 0이었다. file:/// 경로로 바로잡았다. 첫 실제 테스트 실패는 옛 whole-app fixture가 gateway 루트에서 flow를 직접 움직여 상담 surface의 disclosure 보존 조건에 닿지 못한 것이었다. fixture URL만 실제 `http://qa.invalid/mvp3/#welcome`로 수정했다. 제품 흐름 재시도/변경으로 숨기지 않았다. `validation-startup-error.json`, `bom-first-failure-correction.json`에 원인과 범위를 남겼다.

네이티브 PC/모바일에서는 2개 카드, 실제 두 번째 선택, GPU native 펼침, disabled 변경 4개, 상담 접기, 저장 버튼, 미연결 BOM/사진과 503 사진 오류 시 정보 보존을 확인했다. 단건 추천 카드 수 1은 확인했으나 사진 오류가 나타났고 loopback GET 200과의 차이는 미해결이다. `browser-observations.json`을 보존하며 단건 사진까지 통과로 셈하지 않는다. 빠른 시나리오 배치의 뒤 검사도 결과 수신 전에 실행된 사실을 숨기지 않는다. 자세한 디자인 차이와 캡처 환경은 `design-qa.md` 참조.

## 확인용 로컬 미리보기

`http://127.0.0.1:60670/mvp3/?scenario=two#welcome`, ‘CODE/MOCK 게임, 100만원 이하로 추천해줘’ 입력 → 실제 기존 상담 처리 경로로 fixture 소비 → 두 번째 카드 상세 → GPU 행 클릭.

이 preview는 localhost static/메모리 fixture이며 실제 고객 API·LLM/DB/GCS를 부르지 않는다. 서버 POST/PUT/PATCH/DELETE는 405, 미지정 API는 차단된다. 본체 예시 파일은 기존 자산을 검사 URL로만 제공하며 실제 SKU 사진이라고 주장하지 않는다. own PID36152는 미리보기를 위해 유지한다. QA 서버·fixture·캡처·보고서는 출력 폴더에만 있고 exact5 제품 패치에 포함되지 않는다.

Codex UI/copy 후보 인계 완료. PM/Claude의 정본 통합, PR10 UI3 실제 제외, 고객 public BOM/photo 계약 연결, 실제 운영 DB/인증/저장·배포 E2E 및 단건 네이티브 사진 원인 확인은 남아 있다.
