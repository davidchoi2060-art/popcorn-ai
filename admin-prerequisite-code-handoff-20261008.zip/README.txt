관리자 기존 원본 연결 후보 인계 — CODE/MOCK 검토용

기존 격리 후보의 수용 입력16과 출처표시 EXACT6의 중복 api/pc_media.py를 합쳐 현재 정확21파일을 보존했다. 각 파일은 baseline raw SHA 또는 최종 pins SHA와 이번에 실제 대조했다. 코드 재작성/새 검사/DB/GCS/배포 실행은 없다. candidate는 main 덮어쓰기용이 아니다.

api/pc_media.py는 GPU 기존 변경 + generated 한정 worker 방어 + jobs 출처 투영이 함께 들어 있다. 기존 개별 patch 및 기준을 비교하고 현 main과 소유 hunk를 확인해야 한다. EXACT6 패치 SHA64ab36dc73f4352fd7f355e07fff4cdcd04b6027c594fe13f0712cdc2c417ae6. 공통 CSS는 PR10 이후 head에서 충돌 확인 필요.

0133_pc_media_import_provenance.py는 과거 revision0133/down0132 그대로다. 현재 main의 같은 번호와 충돌하므로 그대로 병합/적용 금지. Claude 댓글6060056630은 main d2c66b3의 revision0133/down0132를 보고했다. 새 revision 연결은 최신 정확 체인과 예약을 다시 확인한 별도 후보에서 검토해야 한다. 이번 배치 migration 수정/실행0.

runtime/authority/admin wiring은 기본 거절을 유지하며 실제 grant 최신화/CASE 생산핀/운영 인증 연결은 미확인이다. 일반 worker는 스키마 origin 열 없을 때 생성도 거절한다. CODE/MOCK/독립 QA/PM 수용/실DB/배포/고객 E2E를 구분한다. 문서의 과거 '수용 대기'는 당시 상태이며 최신 인계를 덮어쓰지 않는다.

화면 후보는 Codex 소유, 서버 현 main 통합·검토는 Claude 기존 담당 소유. 새 UI 디자인/A1A3 전체 흐름/원본 재생성/새 UUID 재등록 권한을 포함하지 않는다. 수신 시 ZIP 및 개별 SHA 대조 후 실제 원응답을 남겨야 한다.
