# 일반 이미지 worker origin 방어 — EXACT2 CODE/MOCK

신규 검사18 PASS, exact2.patch reverse check PASS. 실제DB/PG/GCS/provider/apply/선택/공개/배포/8790/재시작0. 독립 QA 및 PM 수용 대기.

## 기준과 정확 변경

격리트리 D:/WORK/PopcornAI/worktrees/existing-media-worker-origin-guard-20261008.
수용 파일 raw15를 그대로 고정한 로컬 baseline 9467d2a87572e4b459aa5c28aec16e43f7883023, parent80b219ae75eb2b7f7d7f49507e6972efaf73a99b. baseline.json은 raw working-file SHA/크기와 HEAD blob SHA/크기를 구분한다. 원래 admin-wiring 트리 raw15 불변, 새트리 raw14 불변을 종료 시 확인했다.

소유 EXACT2만 로컬 미커밋:
- api/pc_media.py work()의 origin 확인 위치 및 retry_storage()의 대상 조건
- 신규 tests/test_pc_media_origin_guard.py

work는 DB행을 읽고 origin_kind='generated'인지 일반 실패 try/except 밖에서 확인한다. existing_import/unknown/null/missing origin은 provider/GCS/로컬 원본읽기/DB UPDATE 없이 반환한다. origin을 읽을 수 없는 DB오류·행없음도 일반 생성 실패 UPDATE를 실행하지 않고 오류를 전파한다. 주체가 불명인 행을 실패로 덮어쓰지 않기 위한 의도된 변화다.

retry_storage는 기존 FOR UPDATE 읽기 이후 origin이 generated인지 먼저 검사하고 아니면409다. 기존 staged/spool 확인보다 먼저 거절하여 import 원본 경로를 검사하지 않으며, running UPDATE 및 background.add_task가 실행되지 않는다. generated의 기존 상태/phase/source 조건은 유지한다. 기존 SELECT FOR UPDATE 자체는 유지한 읽기이며 import 행 DML은 없다.

generated는 기존 generation/storage_only, staged bytes/spool fallback, upload/ready 및 generation/storage 실패 UPDATE 흐름을 유지한다. GPU optional 로직·구suite/authority/runtime/schema/route/consumer/main/auth는 수정하지 않았다. diff는 work의 초기행읽기/guard 위치와 retry 조건 두 hunk뿐이다.

## missing origin의 실제 스키마 근거와 배포 전제

0120_pc_media.py는 origin_kind가 없는 원래 스키마다. 0133_pc_media_import_provenance.py UPGRADE_SQL은 origin_kind TEXT NOT NULL DEFAULT 'generated'를 추가하므로 적용 후 기존 행과 새 일반 INSERT는 DB에 명시적 generated 열값을 갖는다. 기존 pc_media.generate INSERT는 해당 DB default를 사용한다.

따라서 missing origin을 코드에서 generated로 간주할 근거가 없으며, 이번에는 fallback을 넣지 않았다. 0133 미적용 DB의 SELECT * 결과에는 origin_kind가 없으므로 일반 생성 worker도 처리하지 않고 저장 재시도는409가 된다. 운영에 반영하려면 먼저0133 실제적용/스키마·기존행 backfill 및 정상generated 경로를 별도 검증해야 한다. 이번 schema 적용·운영 확인0. CODE/MOCK 수용을 배포 가능 판정으로 확대하지 않는다.

## 신규 검증

D:/DEV/popcorn-ai/.venv/Scripts/python.exe로 신규 파일만 실행해18 PASS. 기존suite 반복0. 기존완료 GPU/authority/runtime/schema/pure 검사 재실행0.

검증 내용: generated 생성/저장 성공, 모델 전달, staged/spool source 및 ready 갱신, generation/storage 실패 흐름, non-running 유지. existing_import의 generation/storage_only, unknown/null/bool/empty/missing origin은 provider/upload/실패UPDATE0. origin 조회오류/행없음에서 실패UPDATE0. retry import/unknown/missing은 상태변경·background예약0, generated storage retry만 기존정확 task예약. import의 spool 경로 probe0.

DB/공급자/upload/permission은 mock이며 SQLAlchemy text와 현재 pc_media 함수를 실행했다. 실제 SQL driver/격리·경합/GCS·운영worker/HTTP middleware E2E는 미검증. guard는 읽은 origin에 대한 방어이며 DB조회 이후 다른 주체가 origin을 바꾸는 임의 동시성까지 검증했다고 주장하지 않는다.

## 남은 경계

최신 grant provider·CASE 생산핀 선택은 이번에 확대하지 않았다. consumer import 출처 표시는 별도 남아 있다. 실제등록과 선택/고객공개/배포는 별도다. HANDOFF/pins/baseline/exact2.patch/origin-guard-tests.txt로 독립QA를 요청한다.
