# Existing media runtime — CODE/MOCK handoff

신규 4파일 구현과 신규 모의 검사 36개(런타임 29, CLI 7)를 완료했다. 실제 PostgreSQL/GCS 호출 및 apply는 0회다. PM 전달에 따르면 독립 QA 신규36 PASS/기능결함0 원보고를 받았다. PM 수용 판정은 대기 중이다.

## 고정 기준과 변경 범위

작업 트리: D:/WORK/PopcornAI/worktrees/case-existing-media-runtime-20261008
상위 기준: 1ecf4dfe31e670bed14c7ce218e88ab187ffc197
승인된 6파일만 통합한 로컬 기준 커밋: da55227e3519217e144cd7afb73d192fa500bc9b
승인 입력 6파일의 raw working-file 바이트와 SHA 보존을 재확인했다. 이는 HEAD blob 6개와 raw 바이트가 모두 일치한다는 뜻이 아니다. baseline.json의 inputs.sha256 및 raw_working_file은 승인 원본 작업 파일을, integrated_head_blob은 위 통합 커밋에 저장된 blob 바이트를 핀한다.

- tests/test_pc_media_not_applicable.py 승인 raw: SHA256 55c416480160b7cca10fce3ed2ad2bbf8f96546c58518feb76b1b04b8f157090, 7570 bytes.
- 동일 파일 integrated HEAD blob: SHA256 e4005e3e1bdae5c8de491cdd89dc62625725ed580a055049b08e7afc6cf9ed58, 7432 bytes.
- 이 파일은 CRLF→LF 정규화 후 내용이 동일하다. 나머지 5파일은 HEAD blob과 raw 바이트가 동일하다. 따라서 승인 raw6 보존과 통합 코드 내용 동일성을 구분해 확인했다.

QA 근거: D:/WORK/PopcornAI/outputs/opening-integration-review-20261005/independent-existing-media-runtime-20261008/baseline-EOL-counterexample.json. 이번 F1 보완은 baseline.json과 HANDOFF.md 문서2만 수정했다. 코드4·patch·입력raw6·통합HEAD는 불변이며 검사 재실행, 커밋 재작성, 실등록·실DB/GCS·배포는 모두 0회다.

신규 변경은 다음 4파일이다. exact4.patch 및 pins.json에 고정했다.
- api/pc_existing_media_import.py
- tools/apply_existing_pc_media.py
- tests/test_pc_existing_media_import.py
- tests/test_apply_existing_pc_media.py

## 구현한 동작

PostgreSQL 예약/완료 어댑터와 GCS create-only 어댑터를 구현했다. 예약은 짧은 트랜잭션에서 커밋하고 업로드는 DB 잠금 밖에서 수행하며, 최종 등록 전에 새 트랜잭션으로 현재 연결·리비전·시각/검토 근거와 독립 권한을 다시 확인한다. 같은 요청의 불변 계획·출처·digest가 다르면 거절한다. 예약 커밋의 결과가 불명확한 경우 같은 요청으로 재조회하고, 확인할 수 없으면 db_unknown을 보존한다. 후보 job UUID는 request UUID 기반 결정값이므로 같은 요청 재시도에 새 job을 만들지 않는다.

GCS 업로드는 ifGenerationMatch=0을 사용한다. 412는 동일 원본 바이트·SHA·크기·PNG·generation을 확인한 경우만 재사용한다. 이미 ready인 요청은 읽기 검증만 수행한다. 덮어쓰기, 자동 삭제, 공급자 생성 요청은 없다.

원본 생성 모델·생성자·생성시각·원본 visual basis는 null로 유지한다. DB job의 actor는 현재 서버 운영자, created_at은 실제 DB 등록시각이다. 원본 QA 및 예외 근거를 manifest 참조와 함께 보존한다. selected=false이며 공개는 별도다.

CLI는 기본 dry-run이며 apply에는 명시적 옵션, 환경 플래그, 코드/기준/현재 근거 pins 및 서버 권한이 모두 필요하다. 환경 플래그나 CLI 입력으로 권한을 부여하지 않는다. 재사용·등록 권한과 CASE 근거의 실제 서버 연결은 아직 미연결이며 기본 거절한다. 따라서 현재 CLI가 실제 등록 가능한 상태라는 뜻이 아니다.

## 검증과 남은 경계

runtime-tests.txt: 29 PASS. cli-tests.txt: 7 PASS. exact4.patch reverse check PASS. 기존 완료 검사 묶음은 재실행하지 않았다.
검사는 모의 연결/응답으로 어댑터와 오케스트레이션을 확인했다. 실제 PostgreSQL SQL/스키마0133/격리·잠금·동시성, 실제 GCS ADC/권한/응답, 실제 서버 권한·CASE 근거 연결, 운영 등록과 UI/E2E는 미검증이다. apply용 expected pins는 승인된 최신 서버 읽기에서 받아야 하며 검토 근거값을 추정하지 않았다.

원래 체크아웃, 실제 DB, 격리 PG, 실제 GCS/provider/network, 8790, 배포와 서비스 재시작은 변경하지 않았다. 신규 파일은 로컬 미커밋 상태이며 검토용 patch로 제공한다.
