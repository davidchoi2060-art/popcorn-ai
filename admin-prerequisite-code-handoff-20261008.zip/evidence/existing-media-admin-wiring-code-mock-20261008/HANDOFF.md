# 기존 원본 관리 요청 연결 — EXACT4 CODE/MOCK

신규route/실자료 검사37 PASS(21+16), exact4.patch reverse check PASS. 제품DB/PG/GCS/provider/nativeSQL/apply/선택/공개/배포/8790/재시작0. 독립 QA/PM 수용 대기. 실제 최신 grant provider와 CASE 생산핀 선택은 미연결이고 기본 거절한다.

## 고정 기준·소유

트리 D:/WORK/PopcornAI/worktrees/existing-media-admin-wiring-20261008.
승인raw12를 원바이트로 고정한 기준 commit 80b219ae75eb2b7f7d7f49507e6972efaf73a99b, parent dd60172b8cbcead572b30f8d6b3566f0e49b528d. baseline.json은 raw working-file 및 integrated HEAD blob을 구분한다.

변경 EXACT4:
- api/admin_existing_pc_media.py 신규
- tests/test_admin_existing_pc_media.py 신규
- api/pc_existing_media_authority.py의 기존파일 끝에 ManifestCasePins/ManifestCaseReader 추가
- tests/test_pc_existing_media_actual_evidence.py 신규

원래 authority 트리의 승인raw12 불변 확인. 새트리에서는 승인11 바이트 불변, authority의 기존 전체 바이트 prefix 불변 확인(추가 코드만 존재). 기존 authority 클래스/기존30 검사파일 수정0. 수용 runtime4/schema/GPU/pure/CLI/auth/main/consumer/worker 수정0. 기존suite 반복0. 신규exact4는 미커밋이며 patch/pins.json으로 고정했다.

## 실제 관리 요청 계약과 factory 준비

POST /api/admin/pc-media/{product_code}/existing-import. 경로는 문자열 '113835'/'113836'만 인정하여 부호/선행0/P접두어/소수/기타SKU를 거절한다. body는 strict/extra forbid, mode 기본dry_run, request_id canonical UUID문자열(apply 필수), expected는 양의 정수 revision과64자리 소문자 해시4개(visual_basis/review_basis/original_sha256/manifest_sha256)다. request_id를 바꾸거나 route에서 새 UUID를 만들지 않는다.

actor/role/session/권한/CASE/key/factory/apply_enabled는 body에서 받지 않는다. 기존 admin_pc_builder.permission(request)의 authenticated operator/owner 및 cross-site 기준을 사용하고, 기존 세션 cookie와 검증된 주체/role/site를 요청 전용 trusted closure로 전달한다. 무세션 fallback1/BackgroundTasks/원격principal/새provider/전체auth 변경0.

build_runtime은 기존 engine+불변archive 경로+PgStore(case_reader)+GcsObjects+ServerAuthority를 조립한다. session.operator_reader는 주체 전달만 한다. reuse wrapper는 반드시 같은 tx.conn에서 SessionAuthority.verify_registration SELECT를 먼저 수행하므로 dry-run 및 ready/불명커밋 재조회에서도 실제 세션 상태를 다시 읽는다. 등록 verifier도 기존 동일연결 검증이다. 네트워크를 DB잠금 안에서 호출하지 않는 수용 runtime 경계를 유지한다.

server_wiring()은 기본 ServerWiring(None,None,False)다. grant/case 미연결은 DB 준비 전에403, apply도 명시 server apply_enabled=True 없으면403. 예외 거절은 일반 메시지이고 세션/DSN을 반환하지 않는다. 연결된 모의 runtime 결과는 Outcome state와 식별자/digest로 반환되며 HTTP200만으로 등록완료를 뜻하지 않는다. main의 module-router 자동발견과 맞춘 APIRouter지만 실제 서버에 파일 반영/route 활성화하지 않았다.

## 최신 허가 응답 계약 — 실제 provider는 미연결

FreshReuseEvidence는 trusted server callback의 결과 계약이다. provider는 매 호출시 정본과 철회 최신성을 실제로 확인할 책임이 있으며 그 운반방식/DB/provider 구현은 선택하지 않았다. 클라이언트나 environment가 이 값을 만들지 않는다. 단순 Decision.ALLOW/bool/dict/문자열 존재는 거절한다.

검증값은 typed Decision.ALLOW, withdrawn is False(불명이면거절), 정확 정본 path/version1/sha818281..., 고정 manifest SHA, 실제 subject의 source SKU/원본SHA/CASE 코드다. 정본 변경·버전 변경·해시 불일치·범위 불일치·철회/철회불명은 거절한다. 기존 재사용 승인을 재승인 문제로 만들지 않고 기존 정본 적용 후보를 고정했으며, 실제 fresh 증거가 없으면 기본 거절한다. 생산 ALLOW 상수나 fixture grant를 기본값으로 설치하지 않았다. 이 응답 계약 자체가 provider의 최신 확인을 증명하거나 grant를 생성하지 않는다.

## 실제 name + 외부 QA reader

ManifestCaseReader는 서버가 고정한 ManifestCasePins와 local manifest reader를 받는다. PM exact2 관찰 파일SHA35413de9... 및 실제 두 행을 신규검사에 사용했다. 관찰2026-10-08T03:30:58Z는 앞으로의 최신성 보장이 아니다.

CASE129552: fingerprint a8a227169962fad6be537cc8fdccfa5985cf56ac5f8d3e692cd4ec86a8945012, contentSHA e5cd36a013d88e21bcf43af93c3f719fd4cb120e9329ae61702c812e59c4db59, name DAVEN N1 MESH (블랙).
CASE129551: fingerprint 8e5b3964b68a97c5d67926e19d8c0f7ce622a5256ab27d3adceaa46fcca6fbb7, contentSHA 343401bd9aa6bfd619e0ee7088bcb4b2de02514d08379b3190be90ca22178e6a, name DAVEN N1 MESH (화이트).

현재 전달된 product_explanations 행 fingerprint/contentSHA/name/slot을 pins와 정확 비교한다. manifest 전체SHA와 해당 SKU CASE code/name/CASE참조 canonical SHA/qa_notes[0]의 전체 명시 문장을 확인한 뒤 제한적 정규화한다. 단순 substring, 산문추측, 유사 모델, 잘못CASE, 변경 name/QA/ref/hash는 거절한다. name을 정확하게 모델·색상으로 분리하고, 닫힌메쉬 외관은 기존 QA 전체 문장과 고정 manifest 근거로 반환한다. 기존 ExplicitCaseReader의 가짜4facts를 채우거나 DBfacts를 백필하지 않는다.

source_reference는 product_explanations 실제 name 경로/원문/fingerprint/contentSHA와 external_QA라는 구분, manifestSHA/정확QA 경로·원문 및 CASE참조hash/url/image_asset을 함께 보존한다. 수용 runtime provenance의 case_evidence.source_reference까지 보존됨을 신규 검사했다. PM관찰값에서 생산 reader를 자동설치하지 않았고 실제 pins 선택은 서버 wiring 후속이다. 원본PNG104/전체DB/새이미지 조회0.

## 검증·남은 결정

D:/DEV/popcorn-ai/.venv/Scripts/python.exe의 실제 FastAPI/Pydantic/TestClient로 신규route21 검사, 기존 PM exact2 JSON+manifest의 해당2 항목을 읽는 실자료16 검사를 수행했다. TestClient는 인프로세스 앱이고 제품네트워크/DB/GCS 호출이 아니다. factory 검사는 engine/세션 응답/fresh grant를 모의 처리했다. 모의 apply는 실제등록0이며 ready재조회 검사는 reuse callback의 세션 재검증 경계를 확인한 것이지 네이티브 ready E2E가 아니다. 이전30/36/0133/GPU/pure suite 실행0.

남은 실행 전 결정: 현재 정본 변경·철회를 매 호출 검증할 실제 trusted provider/전달 원천, 서버 CASE pins의 선택·갱신 절차, 구체 apply 범위 및 실제 schema/권한/SQL·GCS 검증. consumer origin표시와 일반worker origin guard는 기존 읽기 이슈로 그대로 남았다. 선택·고객공개·배포는 등록과 별도다. 이 구현으로 actual apply 가능하다고 보고하지 않는다.
