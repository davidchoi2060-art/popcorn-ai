# 승인된 관리자 출처 표시 구현 — EXACT6 CODE/MOCK

대표 2026-10-08 PM채팅 '시안 승인.. 진행해'에 따라 구현. API10 PASS(이전 결과 유지)+JS표시29 PASS(P2 수정 후 실행)=총39 PASS, exact6.patch reverse check PASS. 독립 QA 및 디자인 실제 브라우저 시각 대조는 요청 대기이며 완료로 보고하지 않는다. 실제DB/PG/GCS/network/provider/등록/선택/공개/배포/8790재시작0.

## 기준·승인·소유

격리트리 D:/WORK/PopcornAI/worktrees/existing-media-origin-display-20261008.
worker수용 raw16 고정 로컬baseline aee2cc515d97987ea692550e10acccab044e1f77, parent9467d2a87572e4b459aa5c28aec16e43f7883023. baseline.json에 raw working-file과 HEAD blob 핀을 별도 기록했다. 승인 시안 HANDOFF/index/design.css/API-DISPLAY-CONTRACT의 전달SHA4개를 직접 확인해 함께 고정했다. 시안 HANDOFF 안의 예전 '대표 확인 미완료' 문구보다 이번 직접 승인 전달이 최신이다.

EXACT6:
1 api/pc_media.py: jobs SELECT와 safe display projection만 변경.
2 mockups/shared/pc-media.js: 출처·상태·메타·neutral busy/preview 문구 표시.
3 mockups/shared/pc-assets.css: 이미지 관리 #media-root에 한정한 승인 배지/메타/구분선 스타일 추가.
4 templates/admin/pc_media.html.j2: 연결CSS/JS cache version만20261008-origin으로 변경.
5 신규 tests/test_pc_media_origin_display.py.
6 신규 tests/test_pc_media_origin_display.cjs.

원래 worker트리 raw16 불변, 새트리 수용raw15 불변 확인. pc_media의 GPU/snapshot 앞부분 및 work() 이후 전체bytes 불변, JS async load()/action handler 이후bytes 불변, 공유CSS 기존 전체prefix 불변 확인. JS 수정 과정의 LF 정규화를 기존CRLF로 복원해 행동코드 tail도 원바이트 유지했다. 기존수용 suites/authority/runtime/schema/routes/main/auth/다른owner 수정0. 신규6 로컬 미커밋이며 pins/patch로 고정.

## API 안전 투영

jobs SELECT는 bound configuration_id/최근20 제한을 유지하며 to_jsonb(j)->>'origin_kind'만 추가한다. pre0133에서도 열이 없으면NULL이므로 임의generated fallback을 하지 않는다. generated/existing_import 명시값만 그대로 투영하고 불명값은null. 실제 native PG의 이 SQL은 미검증이다.

표시DTO는 기존job 필드의 whitelist와 origin_kind, null registration_actor_label/original_created_at/original_creator_label/reuse_approval_status/publication_status만 반환한다. 검증원천이 없는 값을 채우지 않는다. raw actor/import_provenance/objectkey/bucket/서버경로를 추가하지 않는다. raw error 원문도 반환하지 않고 failed에는 출처/단계별 안전 일반문구를 반환한다. import model은null, generated null도null 유지하고 상단 기본 생성 모델로 대체하지 않는다. 현재 s.model은 기존 생성준비 설정으로만 유지한다.

state의 current/image_url/interrupted 계산과 선택/권한 계약은 그대로다. created_at은 현재 요청 행 기록시각이며 원본 생성/저장완료로 바꾸지 않는다. 조회는 판정/쓰기/권한 부여가 아니다.

## 승인 UI 구현

갤러리는 '이미지 목록', 필터/빈목록은 중립 문구. 각 카드에 별도의 출처 배지와 상태 배지를 표시한다. generated / existing_import / 불명값별 running/failed/ready 및 phase 문구는 승인 계약을 따른다. 불명 status는 '상태 확인 필요'. exception/error 원문은 UI에서 사용하지 않는다.

원본 생성 기록, 해당job 모델, 현재 등록시각과 등록주체, 원본 재사용/대표선택/고객공개를 분리한다. 생성자·시각은 기록없음/미확인, 등록주체 미확인, 승인·공개 미확인이다. selected/ready/imageURL로 승인이나 공개를 추정하지 않는다. import 모델은 해당없음/기존원본반입·생성실행없음, generated/불명 null은 모델기록없음이다.

생성준비영역 유지. 전체running을 요약할 때 generated만 생성 문구, import만 원본등록문구, 혼합/불명은 이미지작업진행중이다. 실행가능 조건은 기존과 같다. selected preview의 alt는 현재선택된대표이미지이며 칩은 실제출처다. interrupted는 작업중단가능·상태확인필요만 덧붙이며 새 UUID/별도생성을 안내하지 않는다.

ready/current/unselected 선택버튼의 기존조건을 모든출처에서 유지한다. 시안의 all-disabled를 정책으로 복사하지 않았다. 일반 storage retry는 generated/failed/storage만 표시하고 기존 staged/cloud/busy조건을 유지한다. import/불명에는 일반worker retry나 재생성안내를 붙이지 않는다. 자동생성/선택/공개0.

기존2열 준비영역/PC3열·중간2열·모바일1열 갤러리의 base CSS 유지. 추가CSS는#media-root로 제한해 다른영상/오디오카드에 전파하지 않는다. native details 구조로 출처·재사용 설명을 접는다. 실제 PC/모바일 시각대조·overflow·브라우저 렌더는 독립 디자인 검토가 남았다.

## 실제 검사 및 시각 인계

api-display-tests.txt 신규10 PASS: 명시origin/legacy missing/개별null모델/미검증null메타/비밀원문제외/실패일반문구/바인드SELECT/기존state 연결/원본불변. 실제 함수·SQLAlchemy text를 사용하고 DB/cloud는 mock.
js-display-tests.txt 신규29 PASS(P2 후 실행): 실제pc-media.js를 Node VM의 DOM/fetch mock에서 실행해 렌더HTML 검증. 3출처, 상태·phase 매핑, 모델기본대체금지, 현재등록/원본생성분리, 승인·선택·공개분리, 선택버튼기존조건, generated retry/import·unknown 차단, 혼합busy, interrupted, escaping 및 비밀필드무사용, neutral빈목록. GET fixture1회뿐이고 mutation/crypto UUID호출0.

기존suite 반복0. JS 검증 후 동일 내용의 기존CRLF만 복원했으며 신규의미코드변경은 없다. 테스트 결과는 실제제품 로그인/DB/GCS/E2E나 실제브라우저 시각검사가 아니다.

rendered-mock-body.html은 실제JS가 9개 mock카드를 렌더한 원문, render-fixture.json은 mock 입력이다. visual-preview.html+implemented-pc-assets.css는 디자인대조용. 반입 ready만 승인시안 assets/existing-case-example.png를 참조하고 generated/불명은 빈SVG표시영역으로 바꿨다. 새이미지생성/편집/복사0. 이프리뷰의이미지대체는 산출물에만 있고 제품JS에는 없다. 기준CASE photo URL도 프리뷰에서빈표시영역이다. shell CSS는 ../existing-media-origin-display-design-20261008/assets/admin2.css를 참조하므로 outputs를 static root로 쓰면 상대경로가 맞는다. 서버를 시작하지 않았다. 버튼은 비동작 정적프리뷰이며 제품의활성조건은 실제JS검사로 확인했다.

다음은 독립CODE/MOCK QA와 승인시안 대비 실제PC/모바일 시각대조다. 최신grant/생산CASE핀/실제등록/선택공개/배포 범위는 확대하지 않았다.

## P2 디자인 검토 반영 — 2026-10-08

독립 디자인의 실제 PC1440/mobile375 검토에서 unknown/import ready카드에 공통 snapshot.notice의 AI 조립예시 문구가 출력되는 P2를 확인했다. 명시 generated 카드만 실제 snapshot.notice를 유지하고, import/unknown ready는 '이미지 예시 · 실제 출고 사진이 아닙니다. 원본 생성 이력은 확인되지 않았습니다.'로 중립화했다. 생성 이력을 단정하거나 원본 재사용 승인을 다시 요구하지 않는다.

P2 수정파일은 소유6 중 pc-media.js 및 신규JS검사 .cjs 두개뿐이다. 다른4 후보파일 SHA 및 원트리raw16/새수용raw15 불변 확인. 기존 PC/mobile 디자인 정본의 나머지 검토결과는 별도 인계 예정이며 수정본 실제브라우저 재대조/독립QA 수용은 아직 대기다. 신규JS검사29 PASS(기존27+새2), API10의 기존 결과 유지/이번재실행0, 구suite0. 추가 사례는 import/unknown에서 공통 AI notice 미사용·출고사진 아님·이력미확인 중립안내, generated 실제notice 유지다.

핀/패치 및 rendered-mock-body/render-fixture/visual-preview를 수정본으로 갱신했다. pins-before-p2.json은 수정전 핀이다. 실제DB/PG/GCS/network/등록선택공개/배포/8790재시작0.
